import {RadiusAgent, MeterAgent, ModemAgent, M2MAgent} from './agent';
import {DB} from '../db';
import {Job, TimeSyncJob} from './job';
import {MeterStatusJob, InstantProfileJob, LoadProfileJob, MeterOutageJob} from './job';
import {ModemStatusJob, ModemInfoJob, ModulePerformanceJob, ModemOutageJob} from './job';
import {FepConn} from '../fep';
import {Logger, NBuffer, Utils} from '../common';
import {FepPacket, LinkInfo} from '../fep/packet';
import {env} from '../env';
import {AppConst} from '../app_const';
const crypto = require('crypto');
const os = require('os');
const dgram = require('dgram');

export class Worker {
    radius: RadiusAgent;
    meter: MeterAgent;
    modem: ModemAgent;
    m2m: M2MAgent;

    jobs: Array<Job>;

    timeSyncJob: TimeSyncJob;
    meterStatus: MeterStatusJob;
    instantProfile: InstantProfileJob;
    loadProfile: LoadProfileJob;
    meterOutage: MeterOutageJob;
    modemStatus: ModemStatusJob;
    modemInfo: ModemInfoJob;
    modulePerformance: ModulePerformanceJob;
    modemOutage: ModemOutageJob;

    rebootMin: number;
    rebootLastCheckTicks: number;
    
    constructor() {
        this.radius = new RadiusAgent();
        this.meter = new MeterAgent();
        this.modem = new ModemAgent();
        this.m2m = new M2MAgent();
        this.jobs = [];

        // 새벽 1시 ~ 새벽 5시 사이 랜덤한 시각에 reboot
        this.rebootMin = 60 + crypto.randomInt(240);
        this.rebootLastCheckTicks = 0;
    }

    async prepare() {
        await this.radius.prepare();
        await this.meter.prepare();
        await this.modem.prepare();
        await this.m2m.prepare((linkInfo: LinkInfo)=>this.onLinkRequest(linkInfo));
        await DB.get().prepare();

        this.jobs.push(new TimeSyncJob(this.meter, this.modem, this.m2m));

        this.jobs.push(new MeterStatusJob(this.meter));
        this.jobs.push(new InstantProfileJob(this.meter));
        this.jobs.push(new LoadProfileJob(this.meter));
        this.jobs.push(new MeterOutageJob(this.meter));

        this.jobs.push(new ModemStatusJob(this.modem));
        this.jobs.push(new ModemInfoJob(this.modem));
        this.jobs.push(new ModemOutageJob(this.modem));

        this.jobs.push(new ModulePerformanceJob(this.m2m));

        // 모듈 HW/FW 버전 정보 갱신
        await this.m2m.updateModuleVersion();

        // 모듈IP 정보 갱신
        await this.m2m.updateModuleIP();

        if (env.debug.fakeServer) {
            let socket = dgram.createSocket('udp4');

            socket.on('error', (err: any) => {
                Logger.warn(`!!_!! fakeServer_Socket error :\n${err.message}`);
                socket.close();
            });

            socket.on('message', async (msg: any, rinfo: any) => {
                Logger.info(`recv from fakeServer(${rinfo.address}:${rinfo.port})`);
                Logger.info(`[${msg.toString()}]`);
                this.m2m.onNoti(msg.toString());
            });

            socket.on('listening', () => {
                const address = socket.address();
                Logger.info(`listening (${address.address}:${address.port}) to fakeServer`);
            });

            let fakeServer = env.debug.fakeServer;
            await new Promise((resolve) => {
                socket.bind(fakeServer.linkPort, resolve);
            });
        }
    }

    async close() {
        await DB.get().close();
        await this.radius.close();
    }

    async onStart() {
        // RADIUS 인증 시도
        Logger.info(`## Worker.onStart _ radiusRequestAuth ...`);
        if (env.security.masterKey?.length > 0) {
            Logger.info(`## Radius_Auth_Result : [REUSE]`);
        } else {
            let authResultCode = await this.radius.requestAuth();
            if (authResultCode === 2001) {
                Logger.info(`## Radius_Auth_Result : [RENEW]`);
            } else {
                Logger.error(`## Radius_Auth_Result : [FAIL]`);
                throw new Error('Radius 인증 실패 !!!');
            }
        }

        for(let job of this.jobs) {
            if (env.debug.lazyStart) {
                job.lastTicks = Date.now();
            } else {
                await job.onStart();
            }
        }
    }

    async onUpdate() {
        for(let job of this.jobs) {
            await job.onUpdate();
        }

        let now = new Date();
        // 5분에 한번씩 리붓여부를 체크한다.
        if (now.getTime() >= this.rebootLastCheckTicks + 300000) {
            this.rebootLastCheckTicks = now.getTime();
            
            // check reboot
            let rebootDay = env.config.options.cpuReset === 0x02;
            if (env.config.options.cpuReset === 0x03) {
                let s = env.config.settings.deviceSerialNo;
                let serialNo = Number(s.substring(s.length - 5));
                if (((serialNo % 30) || 30) === now.getDate()) {
                    rebootDay = true;
                }
            }

            if (rebootDay) {
                // 마지막 reboot 이후 6시간 이상 지난 경우만 reboot 시도함
                if (os.uptime() > 3600 * 6) {
                    let minutes = now.getHours() * 60 + now.getMinutes();

                    // 60분 동안만 체크한다.
                    if (minutes >= this.rebootMin && minutes < this.rebootMin + 60) {
                        Utils.reboot();
                    }
                }
            }
        }
    }

    onLinkRequest(linkInfo: LinkInfo) {
        // 0x01: 인증서버, 0x02: FEP서버
        if (linkInfo.serverType.v === 0x01) {
            this.radius.requestAuth();
        } else {
            FepConn.startLink(linkInfo, (packet:FepPacket, conn:FepConn)=>{this.onLinkPacket(packet, conn)});
        }
    }

    async onLinkPacket(packet: FepPacket, conn: FepConn) {
        for(let job of this.jobs) {
            let res = await job.response(packet, conn);
            if (res !== 0) {
                break;
            }
        }
    }
}