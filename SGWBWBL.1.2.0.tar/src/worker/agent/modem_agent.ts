import {env} from '../../env';
import {ModemStatus, ModemInfo, ModulePerformance, ModemOutage} from '../../data';
import {AppConst} from '../../app_const';
import {Logger} from '../../common';
import {execSync} from 'child_process';

export class ModemAgent {
    lastModemStatus: ModemStatus | null;
    lastModemPerformance: ModulePerformance | null;

    constructor() {
    }

    async prepare() {
        
    }

    async collectModemStatus(): Promise<ModemStatus> {
        let data = new ModemStatus();
        data.fepIP = env.config.options.fepIP;
        data.fepPort = env.config.options.fepPort;
        data.aaaIP = env.config.options.aaaIP;
        data.aaaPort = env.config.options.aaaPort;
        data.modemIP = AppConst.modemIP;
        data.m2mId = env.config.settings.m2mId;
        data.iTime = new Date();
        data.hwVersion = env.config.factory.hwVersion;
        data.fwVersion = AppConst.fwVersion;
        data.fBuild = AppConst.fBuild;
        data.protocolVersion = AppConst.protocolVersion;
        data.lteHwVersion = AppConst.lteHwVersion;
        data.lteFwVersion = AppConst.lteFwVersion;
        data.tMask = env.config.options.tMask;
        data.lpPeriod = env.config.options.lpPeriod;
        data.insPeriod = env.config.options.insPeriod;
        data.epfPeriod = env.config.options.epfPeriod;
        data.mcqPeriod = env.config.options.mcqPeriod;
        data.miPeriod = env.config.options.miPeriod;
        data.msPeriod = env.config.options.msPeriod;
        data.pLength = env.config.options.pLength;
        data.trapInterval = env.config.options.trapInterval;
        data.mTimeErrorLimit = env.config.options.mTimeErrorLimit;
        data.mTimePeriod = env.config.options.mTimePeriod;
        data.cpuReset = env.config.options.cpuReset;
        data.timeout = env.config.options.timeout;
        data.pushOrPolling = env.config.options.pushOrPolling;

        return data;
    }

    async collectModemInfo(verifyCode: Buffer): Promise<ModemInfo | null> {
        let data = new ModemInfo();
        data.vCode = env.config.factory.vCode;
        data.yymm = env.config.factory.yymm;
        data.mNum = env.config.factory.mNum;
        data.hwVersion = env.config.factory.hwVersion;
        data.fwVersion = AppConst.fwVersion;
        data.fBuild = AppConst.fBuild;
        data.systemTitle = env.config.settings.systemTitle;
        data.imageHash = Buffer.alloc(32);
        // TODO: imageHash 계산
        
        return data;
    }

    async collectModemOutage(): Promise<ModemOutage> {
        let data = new ModemOutage();

        return data;
    }

    async setModemTime(date: Date) {
        try {
            execSync(`sudo /bin/date --set="${date.toISOString()}"`);
        } catch(err) {
            Logger.warn(`!!_!! ModemAgent.setModemTime : ${err.message}`)
        }
    }
}