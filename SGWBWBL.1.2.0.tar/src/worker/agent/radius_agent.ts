const dgram = require('dgram');
import {NBuffer, Logger, Signals} from '../../common';
import {ENV, env} from '../../env';
import {RadiusPacket, RadiusAuthResponse, RadiusAuthResult} from '../../radius';
import {DB} from '../../db';

export class RadiusAgent {
    trapSocket: any;
    lastTransactionId: number;
    signal: Signals;

    constructor() {
        this.lastTransactionId = 1;
        this.signal = new Signals({shareWait: true});
    }

    async prepare() {
        let socket = dgram.createSocket('udp4');
        this.trapSocket = socket;

        socket.on('error', (err: any) => {
            Logger.warn(`!!_!! radius.trapSocket error :\n${err.message}`);
            socket.close();
        });

        socket.on('message', async (msg: any, rinfo: any) => {
            Logger.info(`trap from ${rinfo.address}:${rinfo.port}`);
            Logger.info(`[${msg.toString('hex')}]`);

            await this.handleTrap(msg);
        });

        socket.on('listening', () => {
            const address = socket.address();
            Logger.info(`server listening ${address.address}:${address.port}`);
        });

        await new Promise((resolve, reject) => {
            socket.bind(env.config.internal.aaaTrapPort, resolve);
        });
    }

    async close() {
        if (this.trapSocket) {
            await new Promise((resolve)=>{
                this.trapSocket.close(resolve);
                this.trapSocket = undefined;
            })
        }
    }

    async requestAuth() : Promise<number> {
        let socket = dgram.createSocket('udp4');

        socket.on('error', (err: any) => {
            Logger.error(`server error:\n${err.stack}`);
            socket.close();
        });
        socket.on('message', async (msg: any, rinfo: any) => {
            Logger.info(`response from ${rinfo.address}:${rinfo.port}`);
            Logger.info(`[${msg.toString('hex')}]`);

            await this.handleResponse(msg);
            socket.close();
        });

        let packet = RadiusPacket.createTxAuthRequest();
        this.lastTransactionId = packet?.header.transactionId.v ?? 0;
        let buf = new NBuffer(packet.size);
        packet.to(buf);
        
        Logger.info(`## RadiusAuthRequest:\n[${buf.v.toString('hex')}]`);
        socket.send(buf.v, 0, buf.offset, env.config.internal.aaaAgentPort, env.config.internal.aaaAgentIP);

        try {
            return await this.signal.wait('RadiusAuthResult', 10000);
        } catch(err) {
            Logger.warn(`!!_!! Radius.requestAuth\n${err.message}`);
            return -1;
        }
    }

    handleResponse(msg: Buffer) {
        try {
            let packet = RadiusPacket.createRx(msg);
            if (packet.data instanceof RadiusAuthResponse) {
                Logger.info(`RadiusAuthResponse : [${JSON.stringify(packet.data)}]`);

                this.signal.signal('RadiusAuthResponse', packet.data.resultCode.v, 1000);
            }
        } catch(err) {
            Logger.warn(`!!_!! Radius.handleResponse\n${err.message}`);
        }
    }

    handleTrap(msg: Buffer) {
        try {
            let packet = RadiusPacket.createRx(msg);
            if (packet.data instanceof RadiusAuthResult) {
                Logger.info(`RadiusAuthResult : [${JSON.stringify(packet.data)}]`);
                ENV.parseSecurity({zkey: packet.data.zKey1.v, cert: packet.data.cert.v.slice(0, packet.data.certLen.v)});
                this.signal.signal('RadiusAuthResult', packet.data.resultCode.v, 1000);
                ENV.saveSecurity();
                DB.get().initInvocationCounter();
            }
        } catch(err) {
            Logger.warn(`!!_!! Radius.handleTrap\n${err.message}`);
        }
    }
}