import {InstantProfile, LoadProfile, MeterStatus, MeterOutage} from '../../data';
import {DB} from '../../db';
import {env, ENV} from '../../env';
import {GuruxLib} from '../../lib/gurux_lib';
import {Logger} from '../../common';

export class MeterAgent {
    constructor() {
    }

    async prepare() {
        GuruxLib.prepare();
        return true;
    }

    async getMeterTime(): Promise<Date | null> {
        let res = await GuruxLib.collectData("0.0.1.0.0.255:2");
        if (!res || res.length !== 1) {
            return null;
        }

        return new Date(res[0]);
    }

    async collectInstantProfile(): Promise<InstantProfile | null> {
        Logger.info(`## InstantProfile 수집 시작`);

        let res = await GuruxLib.collectProfileGenericByEntity("1.1.98.128.0.255", 1, 1);
        if (!res || res.length !== 1) {
            return null;
        }

        let array: Array<string> = res[0];
        if (!array || !Array.isArray(array) || array.length !== 18) {
            return null;
        }

        let meterTime = await this.getMeterTime();
        if(!meterTime) {
            return null;
        }

        let i = 0;
        let data = new InstantProfile();
        data.mid = env.config.settings.meterId;
        data.iTime = new Date();
        data.mTime = meterTime;

        data.amp_A = Number(array[i++]);
        data.vol_A = Number(array[i++]);
        data.vol_thd_A = Number(array[i++]);
        data.pf_A = Number(array[i++]);
        data.vi_phase_A = Number(array[i++]);

        data.amp_B = Number(array[i++]);
        data.vol_B = Number(array[i++]);
        data.vol_thd_B = Number(array[i++]);
        data.pf_B = Number(array[i++]);
        data.vi_phase_B = Number(array[i++]);

        data.amp_C = Number(array[i++]);
        data.vol_C = Number(array[i++]);
        data.vol_thd_C = Number(array[i++]);
        data.pf_C = Number(array[i++]);
        data.vi_phase_C = Number(array[i++]);

        data.vol_phase_AB = Number(array[i++]);
        data.vol_phase_AC = Number(array[i++]);
        data.temperature = Number(array[i++]);

        Logger.info(`## InstantProfile 수집 성공\n${JSON.stringify(data, undefined, 4)}`);
        return data;
    }

    async collectLoadProfiles(): Promise<Array<LoadProfile> | null> {
        Logger.info(`## LoadProfiles 수집 시작`);

        let lastLPIndex = DB.get().getLastLPIndex();
        let res = await GuruxLib.collectLoadProfiles(lastLPIndex);
        if (!res || res.length === 0) {
            return null;
        }

        let newLastLPIndex = Number(res[0]);
        if (!newLastLPIndex) {
            return null;
        }

        Logger.info(`>> oldIndex: [${lastLPIndex}], newIndex: [${newLastLPIndex}]`)

        let array: Array<LoadProfile> = [];
        for(let i = 1; i < res.length; ++i) {
            let data = this.parseLoadProfile(res[i]);
            if (data) {
                array.push(data);
            }
        }

        Logger.info(`## LoadProfiles 수집 성공\n${JSON.stringify(array, undefined, 4)}`);

        DB.get().saveLastLPIndex(newLastLPIndex);

        return array;
    }

    async collectLoadProfilesByRange(start: Date, end: Date): Promise<Array<LoadProfile> | null> {
        Logger.info(`## collectLoadProfilesByRange(start: ${start.toString()}, end: ${end.toString()}) 수집 시작`);

        let res = await GuruxLib.collectLoadProfileByRange(start, end);
        if (!res || res.length === 0) {
            return null;
        }

        let array: Array<LoadProfile> = [];
        for(let i = 1; i < res.length; ++i) {
            let data = this.parseLoadProfile(res[i]);
            if (data && data.cTime >= start && data.cTime <= end) {
                array.push(data);
            }
        }

        Logger.info(`## collectLoadProfilesByRange 성공 [${array.length} 개]`);

        return array;
    }

    async collectMeterStatus(): Promise<MeterStatus | null> {
        Logger.info(`## MeterStatus 수집 시작`);

        // * 계량기 ID :  manufacturer (1.0.0.0.1.255:2) , customer (1.0.0.0.0.255:2) 조합 => 설정파일
        // * COSEM 계기 식별자 : 0.0.42.0.0.255:2
        // * 계량기 시각 : 0.0.1.0.0.255:2
        // * LoadProfile Capture Period : 1.1.0.8.4.255: 2
        // * 통신속도 : 0.0.22.0.0.255:2
        // * 유효전력량 계기정수 : 1.1.0.3.0.255:2
        // * 무효전력량 계기정수 : 1.1.0.3.1.255:2
        // * 피상전력량 계기정수 : 1.1.0.3.2.255:2

        let obisCodes = [
            "0.0.42.0.0.255:2",
            "0.0.1.0.0.255:2",
            "1.1.0.8.4.255:2",
            "0.0.22.0.0.255:2",
            "1.1.0.3.0.255:2",
            "1.1.0.3.1.255:2",
            "1.1.0.3.2.255:2",
        ]

        let res = await GuruxLib.collectData(obisCodes);
        if (!res || res.length !== 7) {
            return null;
        }

        let data = new MeterStatus();
        data.mid = env.config.settings.meterId;
        data.mac = Buffer.from(env.config.settings.ctn);
        data.deviceName = res[0];
        data.iTime = new Date();
        data.mTime = new Date(res[1]);
        data.lpPeriod = Number(res[2]);
        data.comSpeed = Number(res[3].substring('Baudrate'.length));
        data.acon = Number(res[4]);
        data.rcon = Number(res[5]);
        data.pcon = Number(res[6]);
        data.netMetering = env.config.settings.netMetering;

        Logger.info(`## MeterStatus 수집 성공\n${JSON.stringify(data, undefined, 4)}`);

        return data;
    }

    async collectMeterOutage(): Promise<Array<MeterOutage> | null> {
        Logger.info(`## MeterOutage 수집 시작`);

        let res = await GuruxLib.collectProfileGenericByEntity("1.0.99.98.1.255", 1, 10);
        if (!res || res.length === 0) {
            return null;
        }

        let array:Array<MeterOutage> = [];
        for(let i = 0; i < res.length; ++i) {
            let row = res[i];
            if (row && row.length === 2) {
                let data = new MeterOutage();
                data.mid = env.config.settings.meterId;
                data.dataType = 1;  // 1: 정전, 2: 복전
                data.mTime = new Date(row[0]);
                data.logCnt = Number(row[1]);
                data.tx = 1;
                array.push(data);   
            }
        }

        Logger.info(`## MeterOutage 수집 성공\n${JSON.stringify(array, undefined, 4)}`);

        return array;
    }

    async collectMeterRestore(): Promise<Array<MeterOutage> | null> {
        Logger.info(`## MeterRestore 수집 시작`);

        let res = await GuruxLib.collectProfileGenericByEntity("1.0.99.98.2.255", 1, 10);
        if (!res || res.length === 0) {
            return null;
        }

        let array:Array<MeterOutage> = [];
        for(let i = 0; i < res.length; ++i) {
            let row = res[i];
            if (row && row.length === 2) {
                let data = new MeterOutage();
                data.mid = env.config.settings.meterId;
                data.dataType = 2;  // 1: 정전, 2: 복전
                data.mTime = new Date(row[0]);
                data.logCnt = Number(row[1]);
                data.tx = 1;
                array.push(data);   
            }
        }
        Logger.info(`## MeterRestore 수집 성공\n${JSON.stringify(array, undefined, 4)}`);

        return array;
    }

    async setMeterTime(time: Date) {
        let data = `${time.getFullYear()}-${time.getMonth()+1}-${time.getDate()}-${time.getHours()}-${time.getMinutes()}-${time.getSeconds()}`;
        Logger.info(`## MeterTime 수정 : ${data}`);
        await GuruxLib.writeData('0.0.1.0.0.255:2', 'Clock', 'DATETIME', data);
    }

    async setLoadProfilePeriod(period: number) {
        Logger.info(`## LoadProfile CapturePeriod 수정 : ${period}`);
        await GuruxLib.writeData('1.1.0.8.4.255:2', 'Register', 'UINT8', period.toString());
    }

    parseLoadProfile(array: Array<string>): LoadProfile | null {
        if (!array || (array.length !== 6 && array.length !== 10)) {
            return null;
        }

        let i = 0;
        let data = new LoadProfile();
        data.mid = env.config.settings.meterId;
        data.iTime = new Date();
        data.fap = Number(array[i++]);
        data.larap = Number(array[i++]);
        data.lerap = Number(array[i++]);
        data.ap = Number(array[i++]);
        data.cTime = new Date(array[i++]);
        data.status = Number('0b' + array[i++]);

        if (array.length === 10) {
            data.rfap = Number(array[i++]);
            data.rlarap = Number(array[i++]);
            data.rlerap = Number(array[i++]);
            data.rap = Number(array[i++]);
        }
        data.tx = 1;
        
        return data;
    }
}