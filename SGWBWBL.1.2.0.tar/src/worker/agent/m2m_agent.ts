import {Logger, Mutex, NBuffer, Signals, Utils} from '../../common';
import {ModulePerformance} from '../../data';
import {LinkInfo} from '../../fep/packet';
import SerialPort = require('serialport');
import {env} from '../../env';
import {AppConst} from '../../app_const';
import { writeFileSync} from 'fs';

export class M2MAgent {
    recvLinkRequest? : (linkInfo: LinkInfo)=>any;
    port: SerialPort;
    mutex: Mutex;
    signal: Signals;
    curCommand: string | null;
    curResponse: Array<string>;

    fwupState: number;
    fwupVersion: string;
    fwupOffset: number;
    fwupBuff: Buffer;

    constructor() {
        this.port = new SerialPort('/dev/ttyAMA4', {baudRate: 115200, autoOpen: false});
        this.mutex = new Mutex();
        this.signal = new Signals();

        this.curCommand = null;
        this.curResponse = [];

        this.fwupState = 0;
        this.fwupOffset = 0;
    }

    async prepare(recvLinkRequest?: (linkInfo: LinkInfo)=>any): Promise<boolean> {
        this.recvLinkRequest = recvLinkRequest;

        await new Promise((resolve, reject)=> {
            this.port.open(err=>err? reject(err) : resolve(0));
        });

        const parserOptions = {
            delimiter: '\r\n',
            includeDelimiter: false
        };
        this.port.pipe(new SerialPort.parsers.Readline(parserOptions)).on('data', chunk=>this.onData(chunk));

        // TODO: M2M 인증 실패 처리
        await this.reauth();

        return true;
    }

    async reauth(): Promise<number> {
        Logger.info(`## M2M (재)인증 시작`);

        // 인증
        let s = env.config.settings;
        let cmd = `AT$OM_AUTH_REQ=${s.serviceCode},${s.deviceModel},${AppConst.fwVersion},${s.deviceSerialNo}`;
        let res = await this.command(cmd, '$OM_AUTH_RSP=');
        if (res !== '2000') {
            // 실패: 어떻게 하지??
            return -1;
        }

        // remote CSE 업데이트(poa)
        let uCseCode = await this.command('AT$OM_U_CSE_REQ', '$OM_U_CSE_RSP=');
        if (uCseCode !== '2004') {
            // 실패: 어떻게 하지??
            return -3;
        }

        Logger.info(`## M2M (재)인증 성공`);

        return 0;
    }

    async subscribe(): Promise<boolean> {
        let res = await this.command('AT$OM_C_SUB_REQ=StoD', '$OM_C_SUB_RSP=')
        return res === '2001';
    }

    async updateModuleVersion(): Promise<boolean> {
        try {
            let res = await this.command('AT+GMR');

            //// [L910XX.028.01 HW:WD-L700L Ver:30]
            let value = this.find('L910XX.', res);
            if (value) {
                let index1 = value.indexOf(' HW:');
                let index2 = value.indexOf('Ver:');
                if (index1 > 0 && index2 > 0) {
                    AppConst.lteFwVersion = value.substring(0, index1).trim();
                    AppConst.lteHwVersion = value.substring(index2+4).trim();
                    return true;
                }
            }
        } catch(err) {
            Logger.warn(`m2m.getModuleIP Error : ${err.message}`);
        }

        return false;
    }

    async updateModuleIP(): Promise<boolean> {
        try {
            let res = await this.command('AT*WWANIP?');

            //// [V4: 10.66.184.82]
            let value = this.find('V4:', res);
            if (value) {
                AppConst.modemIP = value.trim();
                return true;
            }
        } catch(err) {
            Logger.warn(`m2m.updateModuleIP Error : ${err.message}`);
        }

        return false;
    }

    async getModuleTime(): Promise<Date | null> {
        try {
            let res = await this.command('AT$$MSTIME?');

            //// [$$MSTIME:0,2021,11,24,10,18,38]
            let value = this.find('$$MSTIME:', res);
            if (!value) {
                return null;
            }

            let tokens = value.split(',');
            if (tokens.length !== 7) {
                return null;
            }

            let mode = Number(tokens[0]); // 0: auto, 1: manual
            let year = Number(tokens[1]);
            let month = Number(tokens[2]);
            let date = Number(tokens[3]);
            let hours = Number(tokens[4]);
            let minutes = Number(tokens[5]);
            let seconds = Number(tokens[6]);

            let d = new Date(year, month - 1, date, hours, minutes, seconds);
            if (d.getTime()) {
                return d;
            }
        } catch(err) {
            Logger.warn(`m2m.getModuleTime Error : ${err.message}`);
        }

        return null;
    }

    async collectModulePerformance(): Promise<ModulePerformance | null> {
        Logger.info(`## ModulePerformance 수집 시작`);

        try {
            let res = await this.command('AT$$DBS');
            if(!res) {
                return null;
            }

            let data = new ModulePerformance();
            data.iTime = new Date();
            data.rsrp = Number(this.find('RSRP:', res)) || 0;
            data.sinr = Number(this.find('SINR:', res)) || 0;
            data.rsrq = Number(this.find('RSRQ:', res)) || 0;

            Logger.info(`## ModulePerformance 수집 성공\n${JSON.stringify(data, undefined, 4)}`);
            return data;

        } catch(err) {
            Logger.warn(`m2m.collectModulePerformance Error : ${err.message}`);
        }

        return null;
    }

    find(key: string, res: Array<string> | string | null): string | null {
        if (!res) {
            return null;
        }
        else if(typeof res === 'string') {
            if (res.startsWith(key)) {
                return res.substring(key.length);
            }
        }
        else {
            for(let str of res) {
                if (str.startsWith(key)) {
                    return str.substring(key.length);
                }
            }
        }

        return null;
    }

    private async write(cmd: string): Promise<number> {
        Logger.info(`#M2M_WRITE: [${cmd}]`);

        return await new Promise((resolve)=>{
            this.port.write(cmd + '\r\n', (error, bytesWritten)=>{
                if (error) {
                    resolve(-1);
                } else {
                    resolve(bytesWritten);
                }
            });
        });
    }

    private async command(cmd: string, asyncResId?: string): Promise<Array<string> | string | null> {
        try {
            await this.mutex.lock();

            // 현재 진행중인 command는 1개여야 한다. OK를 수신하거나 timeout이면 끝난다.
            this.curCommand = cmd;

            try {
                let bytesWritten = await this.write(cmd);
                if (bytesWritten < 0) {
                    return null;
                }

                let response = await this.signal.wait('OK', 1000);
                if (!asyncResId) {
                    return response;
                }

            } catch(err) {
                Logger.warn(`AT Cmd[${cmd}]\n Error : ${err.message}`);
            }
        } catch(err) {
            Logger.warn(`AT Cmd[${cmd}]\n Error : ${err.message}`);
        } finally {
            this.curCommand = null;

            this.mutex.unlock();
        }

        if (asyncResId) {
            try {
                return await this.signal.wait(asyncResId, 10000);
            } catch(err) {
                Logger.warn(`AT Cmd[${cmd}]\n Error : ${err.message}`);
            }
        }

        return null;
    }

    async onModuleUpgrade(text: string) {
        if (text.startsWith('$OM_MODEM_FWUP_RSP=')) {
            let resVal = text.substring('$OM_MODEM_FWUP_RSP='.length);
            let tokens = resVal.split(',');
            if (tokens.length < 2) {
                return;
            }

            let resCode = Number(tokens[0]); // 2000: 성공, 9001: 최신 버전, 기타: 실패
            let version = tokens[1]; // 등록된 upgrade 버전
            
            // 모듈에서 자동으로 업그레이드를 시작한다.
            if (resCode === 2000) {
                await this.command('AT$OM_MODEM_FWUP_START');
            }
        }
        else if (text === '$OM_MODEM_FWDL_START') {
            // 펌웨어 다운로드가 시작되었다.
        }
        else if (text === '$OM_MODEM_FWDL_FINISH') {
            // 펌웨어 다운로드가 완료되었다.
        }
        else if (text === '$OM_MODEM_UPDATE_START') {
            // 펌웨어 업데이트가 시작되었다.
        }
        else if (text === '$OM_MODEM_UPDATE_FINISH') {
            // 펌웨어 업데이트가 완료되었다.
            
            // TODO: $OM_MODEM_UPDATE_FINISH를 수신한 단말은 oneM2M플랫폼 재 접속 후 완료 사실을 통보 하여야 한다.
            await this.reauth();
            await this.command('AT$OM_MODEM_FWUP_FINISH');
        }
    }

    async onModemUpgrade(text: string) {
        if (text.startsWith('$OM_DEV_FWUP_RSP=')) {
            let resVal = text.substring('$OM_DEV_FWUP_RSP='.length);
            let tokens = resVal.split(',');
            if (tokens.length < 2) {
                return;
            }

            let resCode = Number(tokens[0]) // 2000: 성공, 9001: 최신 버전, 기타: 실패
            let version = tokens[1] // 등록된 upgrade 버전
            if (resCode === 2000) {
                // TODO: 펌웨어 업그레이드 구현 !!
                this.fwupState = 1;
                this.fwupVersion = version;
                await this.command('AT$OM_DEV_FWUP_START');
            }
            Logger.info(`#ModemUpgrade: [${resCode}]`);
        }
        else if (text.startsWith('$OM_DEV_FWDL_START=')) {
            let length = Number(text.substring('$OM_DEV_FWUP_RSP='.length));
            this.fwupState = 2;
            this.fwupBuff = Buffer.alloc(2 * length + 100);
            Logger.info(`#OM_DEV_FWDL_START: this.fwupState [${this.fwupState}]`);
        }
        else if (text.startsWith('$OM_DEV_FWDL_FINISH')) {
            // TODO: Update가 완료된 단말은 Reboot 및 oneM2M 재 접속 후 M2MM으로 완료 사실을 통보 하여야 한다. 

            Logger.info(`#OM_DEV_FWDL_FINISH: this.fwupState [${this.fwupState}]`);
            //    let file = `../images/f_modem_v${this.fwupVersion}.img`;
            //    fs.writeFileSync(file, this.fwupBuff);
            Logger.info(`#OM_DEV_FWDL_FINISH: this.fwupBuff length [${this.fwupBuff.length}]`);
                let targetVersionFile = `../service/target_version`;
                writeFileSync(targetVersionFile, this.fwupBuff);

                await Utils.sleep(3000);

                Utils.reboot();
      

            // this.fwupState = 3;
            // AT$OM_DEV_FWUP_FINISH
            // this.fwupState = 4;
        }
    }

    async onNoti(text: string) {
        //Logger.info(`m2m_onNoti: [${text}]`);
        //let resVal = text.substring('$OM_R_RCIN_RSP='.length);
        let tokens = text.split(',');
        Logger.info(`m2m_onNoti_tokens: [${tokens[0]}]-[${tokens[1]}]-[${tokens[2]}]`);

        let container = tokens[0];          // container 이름 ($OM_N_INS_RSP=StoD)
        let length = Number(tokens[1]);     // 수신한 데이터 사이즈
        let data = tokens[2];               // 수신한 데이터 내용 (base64 encoding)
        let buff = Buffer.from(data, 'base64');

        // LinkInfo
        // serverType = this.HEX(1);
        // serverIP = this.HEX(4);
        // serverPort = this.HEX(2);
        // serverProtocol = this.HEX(1);
        // serverTime = this.DATE();
        // requestId = this.ASCII(32);
        let linkInfo = new LinkInfo();
        if (buff.length !== linkInfo.size) {
            Logger.warn(`OneM2M_onNoti : data size[${buff.length}] !== linkInfo size[${linkInfo.size}]`);
            return;
        }

        linkInfo.from(new NBuffer(buff));
        Logger.info(`LINK_INFO : [${JSON.stringify(linkInfo)}]`);

        if (this.recvLinkRequest) {
            this.recvLinkRequest(linkInfo);
        }
    }

    private onData(data: any) {
        // TODO: 펌웨어 업그레이드 중이라면 펌웨어 데이터이다!
        if (this.fwupState === 2) {
            Logger.info(`#FW_DATA: [${data.toString('hex')}]`);
            let buff = Buffer.from(data);
            this.fwupOffset += buff.copy(this.fwupBuff, this.fwupOffset);
            return;
        }

        let text: string = data.toString();
        Logger.info(`#M2M_RECV: [${text}]`);

        // 아래 조건문 순서 중요!
        if (text.startsWith('$OM_MODEM_')) {
            this.onModuleUpgrade(text);
        }
        else if (text.startsWith('$OM_DEV_')) {
            this.onModemUpgrade(text);
        }
        else if (text.startsWith('$OM_RESET')) {
            Utils.reboot();
        }
        else if (text.startsWith('$OM_FACTORY_RESET')) {
            Utils.factoryReset();
        }
        else if (text.startsWith('$OM_N_INS_RSP=') || text.startsWith('$OM_R_RCIN_RSP=')) {
            this.onNoti(text);
        }
        else if (text.startsWith('$OM_')) {
            let resId = this.signal.find((id)=>text.startsWith(id));
            if (resId) {
                let resVal = text.substring(resId.length);
                this.signal.signal(resId, resVal);
            }
        }
        else if (text === 'OK') {
            this.signal.signal('OK', this.curResponse);
            if (this.curResponse.length > 0) {
                this.curResponse = [];
            }
        }
        else if (this.curCommand) {
            this.curResponse.push(text);
        }
    }
}