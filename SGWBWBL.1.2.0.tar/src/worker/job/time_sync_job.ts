import {FepConn} from '../../fep';
import {TimeSync, MeterStatus} from '../../data';
import {Job} from './job';
import {Utils, Logger} from '../../common';
import {MeterAgent, ModemAgent, M2MAgent} from '../agent';
import {FepPacket, RxModemSetupTime, RxMeterSetupTime, RxMeterSetupTimeDump, RxStationTimeSyncDump, RxStationTimeSync} from '../../fep/packet';
import {TxMeterTimeSyncDump, TxMeterTimeSync, TxStationTimeSyncDump, TxStationTimeSync, TxModemStatus, TxMeterStatusDump} from '../../fep/packet';
import {env} from '../../env';

export class TimeSyncJob extends Job {
    meter: MeterAgent;
    modem: ModemAgent;
    m2m: M2MAgent;

    constructor(meter: MeterAgent, modem: ModemAgent, m2m: M2MAgent) {
        super('TimeSync', 'mTimePeriod');
        this.meter = meter;
        this.modem = modem;
        this.m2m = m2m;
    }

    async onStart() {
        // 부팅시 기지국과 시각 동기화한다.
        await this.syncStationMeterTime();
    }

    // collect 함수가 주기적으로 실행되기 때문에 여기서 계량기 시각이 오차범위에서 벗어나는지를 체크한다.
    async collect() {
        Logger.info(`## 계량기 시각 오차 확인중...`);
        await this.syncModemMeterTime(false);
    }

    // 계량기 시각 오차 체크
    async syncModemMeterTime(force: boolean) {
        // 계량기 시각 읽기
        let meterTime = await this.meter.getMeterTime();
        if (!meterTime) {
            return;
        }

        let modemTime = new Date();

        let doit = force;
        if (!force) {
            doit = Math.abs(meterTime.getTime() - modemTime.getTime()) > env.config.options.mTimeErrorLimit * 60 * 1000;
            if (doit) {
                Logger.info(`## 계량기 시각 오차 발생 !!! - 시각 동기화 시도`);
            }
        }

        if (doit) {
            // 계량기 시각 바꾸고
            await this.meter.setMeterTime(modemTime);

            // 새로 바뀐 시각을 읽어온다.
            let newMeterTime = await this.meter.getMeterTime();
            if (!newMeterTime) {
                return;
            }
            let newModemTime = new Date();

            let data = new TimeSync();
            data.mid = env.config.settings.meterId;
            data.mType = 0x01; //G-Type
            data.mTimeBefore = meterTime;
            data.dTimeBefore = modemTime;
            data.mTimeError = Utils.timeDiff2BCD(meterTime, modemTime);
            data.mTimeAfter = newMeterTime;
            data.dTimeAfter = newModemTime;

            await this.trap({data, command: 'c'});
        }
    }

    async doTrap(args: any): Promise<number> {
        let command: string = args.command;

        if (command === 'c') {
            let data: TimeSync = args.data;
            let tx = new TxMeterTimeSyncDump();
            let syncData = new TxMeterTimeSync();
            syncData.fromModel(data);
            tx.push(syncData);
            return await FepConn.startTrapDump(command, tx, data);
        }
        else if (command === 'i') {
            let data: TimeSync = args.data;
            let tx = new TxStationTimeSyncDump();
            let syncData = new TxStationTimeSync();
            syncData.fromModel(data);
            tx.push(syncData);
            return await FepConn.startTrapDump(command, tx, data);
        }
        else if (command === 'h') {
            let data: MeterStatus = args.data;
            let tx = new TxMeterStatusDump();
            tx.subCmd.v = args.subCmd;
            tx.fromModels([data]);
            return await FepConn.startTrapDump('h', tx, data);
        }

        return 0;
    }

    async changeMeterTime(meterTime: Date) {
        await this.meter.setMeterTime(meterTime);
        let data = await this.meter.collectMeterStatus();
        await this.trap({data, command: 'h'});
    }

    async syncStationMeterTime() {
        Logger.info(`## 기지국-계량기 시각 동기화 시작`);

        let moduleTime = await this.m2m.getModuleTime();
        if (!moduleTime) {
            return;
        }

        // 먼저 모뎀 시각을 기지국(모듈) 시각과 동기화 한다.
        await this.modem.setModemTime(moduleTime);

        // 계량기 시각 읽기
        let meterTime = await this.meter.getMeterTime();
        if (!meterTime) {
            return;
        }

        // 모뎀 시각 읽기
        let modemTime = new Date();

        // 계량기 시각 바꾸고
        await this.meter.setMeterTime(modemTime);

        // 새로 바뀐 시각을 읽어온다.
        let newMeterTime = await this.meter.getMeterTime();
        if (!newMeterTime) {
            return;
        }
        let newModemTime = new Date();

        let data = new TimeSync();
        data.mid = env.config.settings.meterId;
        data.mType = 0x01; //G-Type
        data.mTimeBefore = meterTime;
        data.dTimeBefore = modemTime;
        data.mTimeError = Utils.timeDiff2BCD(meterTime, modemTime);
        data.mTimeAfter = newMeterTime;
        data.dTimeAfter = newModemTime;

        await this.trap({data, command: 'i'});
    }

    async response(rx: FepPacket, conn: FepConn): Promise<number> {
        let data = rx.data;
        if (data instanceof RxModemSetupTime) {
            // 모뎀 시각 설정
            await this.modem.setModemTime(data.iTime.v);

            // modem_status를 Response로 보낸다.
            let modemStatus = await this.modem.collectModemStatus();
            let tx = new TxModemStatus();
            tx.fromModel(modemStatus);
            await conn.socket.sendData('b', tx, modemStatus, rx.header.qsn.v, 3, true, undefined);

            // 무선모뎀 시간 설정시 모뎀은 계기에 시간동기화를 진행하여 모뎀과 계기의 시간을 동기화해야 한다. (trap 전송(c))
            await this.syncModemMeterTime(true);
            return 2;
        }
        else if (data instanceof RxMeterSetupTimeDump) {
            // 먼저 Ack를 보낸다.
            conn.socket.sendAck(rx.header.qsn.v);
            
            for(let sub of data.dump) {
                if (sub instanceof RxMeterSetupTime) {
                    if (sub.mid.v === env.config.settings.meterId) {
                        // 계량기의 시각을 바꾼다. (trap 전송(h))
                        await this.meter.setMeterTime(sub.mTime.v);
                        let data = await this.meter.collectMeterStatus();
                        if (data) {
                            // 무선모뎀은 전력량계 시간과 모뎀의 시간을 동기화 한다.
                            data.iTime = data.mTime;
                            this.modem.setModemTime(data.mTime);
                            await this.trap({data, command: 'h'});
                        }

                        return 2;
                    }
                }
            }
            return -1;
        }
        else if (data instanceof RxStationTimeSyncDump) {
            // 먼저 Ack를 보낸다.
            conn.socket.sendAck(rx.header.qsn.v);

            for(let sub of data.dump) {
                if (sub instanceof RxStationTimeSync) {
                    if (sub.mid.v === env.config.settings.meterId) {
                        // 모뎀, 계량기 시각을 기지국에 동기화 한다.
                        await this.syncStationMeterTime();
                        return 2;
                    }
                }
            }
            return -1;
        }

        return 0;
    }
}