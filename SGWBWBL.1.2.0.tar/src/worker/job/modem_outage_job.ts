import {FepConn} from '../../fep';
import {ModemOutage} from '../../data';
import {Job} from './job';
import {ModemAgent} from '../agent';
import {FepPacket, TxModemOutage} from '../../fep/packet';

export class ModemOutageJob extends Job {
    modem: ModemAgent;

    constructor(modem: ModemAgent) {
        super('ModemOutage');
        this.modem = modem;
    }

    async doTrap(data: ModemOutage): Promise<number> {
        let tx = new TxModemOutage();
        tx.fromModel(data);
        return await FepConn.startTrap('n', tx, data);
    }

    async response(rx: FepPacket, conn: FepConn): Promise<number> {
        return 0;
    }
}