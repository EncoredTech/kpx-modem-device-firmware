import {FepConn} from '../../fep';
import {Job} from './job';
import {ModemAgent} from '../agent';
import {FepPacket, RxModemInfo, TxModemInfo} from '../../fep/packet';

export class ModemInfoJob extends Job {
    modem: ModemAgent;

    constructor(modem: ModemAgent) {
        super('ModemInfo');
        this.modem = modem;
    }

    async response(rx: FepPacket, conn: FepConn): Promise<number> {
        let data = rx.data;
        if (data instanceof RxModemInfo) {
            let modemInfo = await this.modem.collectModemInfo(data.verifyCode.v);
            if (!modemInfo) {
                return -9;
            }

            let tx = new TxModemInfo();
            tx.fromModel(modemInfo);

            let result = await conn.socket.sendData('p', tx, modemInfo, rx.header.qsn.v, 3, true);
            return result === 0? 1 : -2;
        }

        return 0;
    }
}