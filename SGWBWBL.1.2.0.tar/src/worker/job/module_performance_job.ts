import {FepConn} from '../../fep';
import {ModulePerformance} from '../../data';
import {Job} from './job';
import {M2MAgent} from '../agent';
import {FepPacket, RxModulePerformance, TxModulePerformance} from '../../fep/packet';

export class ModulePerformanceJob extends Job {
    m2m: M2MAgent;
    performance: ModulePerformance | null;

    constructor(m2m: M2MAgent) {
        super('ModulePerformance', 'mcqPeriod');
        this.m2m = m2m;
        this.performance = null;
    }

    async collect() {
        this.performance = await this.m2m.collectModulePerformance();
        return this.performance;
    }

    async doPush(data: ModulePerformance): Promise<number> {
        let tx = new TxModulePerformance();
        tx.fromModel(data);
        return await FepConn.startTrap('g', tx, data);
    }

    async response(rx: FepPacket, conn: FepConn): Promise<number> {
        let data = rx.data;
        if (data instanceof RxModulePerformance) {
            if (!this.performance) {
                return -9;
            }

            let tx = new TxModulePerformance();
            tx.fromModel(this.performance);

            let result = await conn.socket.sendData('g', tx, this.performance, rx.header.qsn.v, 3, true);
            return result === 0? 1 : -2;
        }

        return 0;
    }
}