import {FepConn, FEP_CONST} from '../../fep';
import {InstantProfile} from '../../data';
import {Job} from './job';
import {MeterAgent} from '../agent';
import {FepPacket, RxInstantProfile, TxInstantProfileDump} from '../../fep/packet';
import {env} from '../../env';

export class InstantProfileJob extends Job {
    meter: MeterAgent;
    profile: InstantProfile | null;

    constructor(meter: MeterAgent) {
        super('InstantProfile', 'insPeriod');
        this.meter = meter;
        this.profile = null;
    }

    async onStart() {
        // 부팅시 한 번 수집해 둔다.
        await this.collect();
    }

    async collect() {
        this.profile = await this.meter.collectInstantProfile();
        return this.profile;
    }

    async doPush(data: InstantProfile): Promise<number> {
        let tx = new TxInstantProfileDump();
        tx.subCode.v = 0x01; // 0x01 : 순시 전압/전류 (고정)
        tx.fromModels([data]);

        await FepConn.startTrapDump('d', tx, data);

        // InstantProfile의 경우 재전송 제외 (실패해도 성공으로 처리)
        return 0;
    }

    async response(rx: FepPacket, conn: FepConn): Promise<number> {
        let data = rx.data;
        if (data instanceof RxInstantProfile) {
            if (data.mid.v !== FEP_CONST.TARGET_ALL_METER && data.mid.v !== env.config.settings.meterId) {
                return -1;
            }

            // 데이터가 없으면 어떻게 하지 ???
            if (!this.profile) {
                return -9;
            }

            let tx = new TxInstantProfileDump();
            tx.subCode.v = 0x01; // 0x01 : 순시 전압/전류 (고정)
            tx.fromModels([this.profile]);

            let result = await conn.socket.sendDump('d', tx, this.profile, rx.header.qsn.v, 3);
            return result === 0? 1 : -2;
        }

        return 0;
    }
}