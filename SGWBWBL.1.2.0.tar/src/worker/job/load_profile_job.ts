import {DB} from '../../db';
import {FepConn, FEP_CONST} from '../../fep';
import {LoadProfile} from '../../data';
import {NData, NDumpSplit, Logger} from '../../common';
import {Job} from './job';
import {MeterAgent} from '../agent';
import {FepPacket, RxLoadProfile, RxLoadProfileMissingDump, RxLoadProfileMissingSubDump, RxLoadProfileMissing} from '../../fep/packet';
import {TxLoadProfileDump, TxLoadProfileSubDump, TxLoadProfile} from '../../fep/packet';
import {env} from '../../env';

export class LoadProfileJob extends Job {
    meter: MeterAgent;

    constructor(meter: MeterAgent) {
        super('LoadProfile', 'lpPeriod');
        this.meter = meter;
    }

    async onStart() {
        // 부팅시 수집해 둔다.
        await this.collect();
    }

    async collect() {
        let data = await this.meter.collectLoadProfiles();
        if (!data || data.length === 0) {
            return null;
        }

        try {
            await DB.get().collection('load_profile').insertMany(data, {ordered: false});
            
        } catch(err) {
            Logger.warn(`!!_!! _db.load_profile.insertMany_\n${err.message}`);
        }

        return data;
    }

    async doPush(data: Array<LoadProfile>): Promise<number> {
        let cursor = DB.get().collection('load_profile').find({mid: env.config.settings.meterId, tx: 1}, {_id: 0});
        let docs = await cursor.sort({cTime: -1}).toArray();
        if (!docs || docs.length === 0) {
            Logger.info(`>> load_profile.doPush db에 대상 없음!`);
            return -9;
        }

        let subCode = (env.config.settings.netMetering === 0 ? 1 : 2);
        let tx = new TxLoadProfileDump(subCode);
        tx.fromModels(docs as Array<LoadProfile>);
        return await FepConn.startTrapDump('e', tx, docs, LoadProfileJob.onSend);
    }

    async doTrap(data: Array<LoadProfile>, args: any): Promise<number> {
        let tx = new TxLoadProfileDump(args.subCode);
        tx.fromModels(data);
        return await FepConn.startTrapDump('e', tx, data, LoadProfileJob.onSend);
    }

    async response(rx: FepPacket, conn: FepConn): Promise<number> {
        let data = rx.data;
        if (data instanceof RxLoadProfile) {
            let subCmd = data.subCmd.v;
            let limit = 0;
            let query: any = {};

            // 양방향 데이터 요청했는데, 순방향 계량기인 경우 데이터 보내지 않는다.
            if (subCmd === 0x02 && env.config.settings.netMetering === 0x00) {
                return -1;
            }

            if (data.mid.v !== FEP_CONST.TARGET_ALL_METER) {
                query.mid = data.mid.v;
            }
            // 미전송 데이터 요청
            if (data.dtype.v === 0x00) {
                query.tx = 1;
                limit = 288;

            // 저장된 모든 데이터 요청
            } else if (data.dtype.v === 0xFF) {
            
            // rx.dtype.v n일치 데이터 요청
            } else {
                query.cTime = {$gte: new Date(Date.now() - data.dtype.v*24*60*60*1000)};
            }

            let cursor = DB.get().collection('load_profile').find(query).sort({mTime:-1});
            if (limit > 0) {
                cursor.limit(limit);
            }
            let docs = await cursor.toArray();
            if (!docs || docs.length === 0) {
                // 데이터가 없으면 어떻게 하지 ???
                return -9;
            }

            let subCode = env.config.settings.netMetering === 0 ? 0x01 : 0x02;
            let tx = new TxLoadProfileDump(subCode);
            tx.fromModels(docs as Array<LoadProfile>);

            let result = await conn.socket.sendDump('e', tx, docs, rx.header.qsn.v, 3, LoadProfileJob.onSend);
            return result === 0? 1 : -2;
        }
        else if (data instanceof RxLoadProfileMissingDump) {
            // 우선 ack를 먼저 보낸 후 trap으로 보낸다.
            await conn.socket.sendAck(rx.header.qsn.v);

            let success = 0;
            for(let sub of data.dump) {
                if (sub instanceof RxLoadProfileMissingSubDump) {
                    if (sub.mid.v === FEP_CONST.TARGET_ALL_METER || sub.mid.v === env.config.settings.meterId) {
                        for(let rx of sub.dump) {
                            if (rx instanceof RxLoadProfileMissing) {
                                let fromTime = rx.mTime.v;
                                let toTime = rx.toTime? rx.toTime.v : new Date();
                                let profiles = await this.meter.collectLoadProfilesByRange(fromTime, toTime);
                                if (!profiles || profiles.length === 0) {
                                    let profile = new LoadProfile();
                                    profile.mid = env.config.settings.meterId;
                                    //profile.iTime;
                                    //profile.cTime;
                                    profile.fap = 0;
                                    profile.larap = 0;
                                    profile.lerap = 0;
                                    profile.ap = 0;
                                    profile.status = 0xff;

                                    profile.rfap = 0;
                                    profile.rlarap = 0;
                                    profile.rlerap = 0;
                                    profile.rap = 0;

                                    let profiles = [profile];
                                    let subCode = env.config.settings.netMetering === 0 ? 0x11 : 0x12;
                                    let tx = new TxLoadProfileDump(subCode);
                                    tx.fromModels(profiles);
                                    let res = await FepConn.startTrapDump('e', tx, profiles);
                                    if (res === 0) {
                                        ++success;
                                    }
                                } else {
                                    let subCode = env.config.settings.netMetering === 0 ? 0x11 : 0x12;
                                    let tx = new TxLoadProfileDump(subCode);
                                    tx.fromModels(profiles);
                                    let res = await FepConn.startTrapDump('e', tx, profiles);
                                    if (res === 0) {
                                        ++success;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return success > 0 ? 1 : -2;
        }

        return 0;
    }

    static async onSend(data: NData | NDumpSplit) {
        if (! (data instanceof NDumpSplit)) {
            Logger.warn(`LoadProfile_Job.onSend : data is not instanceof NDumpSplit`);
            return;
        }

        let sub = data.twoHead as TxLoadProfileSubDump;
        if (! (sub instanceof TxLoadProfileSubDump)) {
            Logger.warn(`LoadProfile_Job.onSend : sub is not instanceof TxLoadProfileSubDump`);
            return;
        }

        let mid = sub.mid.v;

        let cTimes = [];
        for(let item of data.array) {
            if (item instanceof TxLoadProfile) {
                cTimes.push(item.cTime.v);
            }
        }

        try {
            let query = {mid, cTime: {$in: cTimes}, tx: 1};
            let result = await DB.get().collection('load_profile').updateMany(query, {$unset: {tx: 1}});
            Logger.info(`>> load_profile.onSend : matchedCount: [${result.matchedCount}], modifedCount: [${result.modifiedCount}]`);
        } catch(err) {
            Logger.warn(`!!_!! _db.load_profile.updateMany_\n${err.message}`);
        }
    }
}