import {DB} from '../../db';
import {FepConn, FEP_CONST} from '../../fep';
import {MeterStatus} from '../../data';
import {Job} from './job';
import {MeterAgent} from '../agent';
import {FepPacket, RxMeterStatus, TxMeterStatusDump} from '../../fep/packet';
import {RxMeterSetupPeriod, RxMeterSetupPeriodDump, RxMeterSetupNetMetering, RxMeterSetupNetMeteringDump} from '../../fep/packet';
import {env} from '../../env';

export class MeterStatusJob extends Job {
    meter: MeterAgent;
    status: MeterStatus | null;

    constructor(meter: MeterAgent) {
        super('MeterStatus', 'msPeriod');
        this.meter = meter;
        this.status = null;
    }

    async onStart() {
        // 부팅시 계량기 상태를 Trap보고한다.
        let status = await this.collect();
        await this.trap(status, {subCmd: 0x01});
    }

    async collect() {
        this.status = await this.meter.collectMeterStatus();
        return this.status;
    }

    async doTrap(data: MeterStatus, args: any): Promise<number> {
        let tx = new TxMeterStatusDump();
        tx.subCmd.v = args.subCmd;
        tx.fromModels([data]);

        return await FepConn.startTrapDump('h', tx, data);
    }

    async doPush(data: MeterStatus): Promise<number> {
        let tx = new TxMeterStatusDump();
        tx.subCmd.v = 0x01; // 계기 상태 데이터
        tx.fromModels([data]);

        return await FepConn.startTrapDump('h', tx, data);
    }

    async sendStatus(rx: FepPacket, conn: FepConn): Promise<number> {
        // 데이터가 없으면 어떻게 하지 ???
        if (!this.status) {
            return -9;
        }

        let tx = new TxMeterStatusDump();
        tx.subCmd.v = 0x01; // 계기 상태 데이터
        tx.fromModels([this.status]);

        let result = await conn.socket.sendDump('h', tx, this.status, rx.header.qsn.v, 3);
        return result === 0? 1 : -2;
    }

    async response(rx: FepPacket, conn: FepConn): Promise<number> {
        let data = rx.data;
        if (data instanceof RxMeterStatus) {
            if (data.mid.v !== FEP_CONST.TARGET_ALL_METER && data.mid.v !==env.config.settings.meterId) {
                return -1;
            }
            // rx.subCode -> 보안모듈 적용 여부 ?? 어떻게 판단하지 ??
            return this.sendStatus(rx, conn);
        }
        else if (data instanceof RxMeterSetupPeriodDump) {
            for(let sub of data.dump) {
                if (sub instanceof RxMeterSetupPeriod) {
                    if (sub.mid.v === FEP_CONST.TARGET_ALL_METER || sub.mid.v === env.config.settings.meterId) {
                        await this.meter.setLoadProfilePeriod(sub.lpPeriod.v);
                        await this.collect();
                        return this.sendStatus(rx, conn);
                    }
                }
            }

            return -1;
        }
        else if (data instanceof RxMeterSetupNetMeteringDump) {
            for(let sub of data.dump) {
                if (sub instanceof RxMeterSetupNetMetering) {
                    if (sub.mid.v === FEP_CONST.TARGET_ALL_METER || sub.mid.v === env.config.settings.meterId) {
                        // TODO: NetMetering 변경 구현
                        // await this.meter.setNetmetering(sub.netMetering.v);
                        // await this.collect();
                        // return this.sendStatus(rx, conn);
                    }
                }
            }

            return -1;
        }

        return 0;
    }
}