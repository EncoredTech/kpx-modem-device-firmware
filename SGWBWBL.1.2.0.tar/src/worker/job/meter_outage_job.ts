import {DB} from '../../db';
import {FepConn, FEP_CONST} from '../../fep';
import {MeterOutage} from '../../data';
import {NData, NDumpSplit, Logger} from '../../common';
import {Job} from './job';
import {MeterAgent} from '../agent';
import {FepPacket, RxMeterOutage, TxMeterOutageDump, TxMeterOutageSubDump, TxMeterOutage} from '../../fep/packet';

export class MeterOutageJob extends Job {
    meter: MeterAgent;

    constructor(meter: MeterAgent) {
        super('MeterOutage', 'epfPeriod');
        this.meter = meter;
    }

    async onStart() {
        // 부팅시 한 번 수집해 둔다.
        await this.collect();
    }

    async collect() {
        let outages = await this.meter.collectMeterOutage() || [];
        let restores = await this.meter.collectMeterRestore() || [];

        if (outages.length === 0 && restores.length === 0) {
            return null;
        }

        if (outages.length > 0) {
            try {
                await DB.get().collection('meter_outage').insertMany(outages, {ordered: false});
            } catch(err) {
                // 계량기에서 중복해서 읽으므로 insert 실패가 빈번히 발생한다.. warn -> info
                Logger.info(`_db.meter_outage.insertMany_ FAIL\n${err.message}`);
            }
        }

        if (restores.length > 0) {
            try {
                await DB.get().collection('meter_restore').insertMany(restores, {ordered: false});
            } catch(err) {
                // 계량기에서 중복해서 읽으므로 insert 실패가 빈번히 발생한다.. warn -> info
                Logger.info(`_db.meter_restore.insertMany_ FAIL\n${err.message}`);
            }
        }

        return outages.concat(restores);
    }

    async doPush(data: Array<MeterOutage>): Promise<number> {
        let tx = new TxMeterOutageDump();
        tx.fromModels(data);
        return await FepConn.startTrapDump('f', tx, data, MeterOutageJob.onSend);
    }

    async response(rx: FepPacket, conn: FepConn): Promise<number> {
        let data = rx.data;
        if (data instanceof RxMeterOutage) {
            let query: any = {};
            if (data.mid.v !== FEP_CONST.TARGET_ALL_METER) {
                query.mid = data.mid.v;
            }
            if (data.dtype.v !== 0x00) {
                query.tx = 1;
            }

            let docs: Array<any> = [];
            if (data.subCode.v !== 0x02) {
                let outages = await DB.get().collection('meter_outage').find(query).sort({mTime:-1}).toArray();
                if (outages && outages.length > 0) {
                    docs = docs.concat(outages);
                }
            }
            if (data.subCode.v !== 0x01) {
                let restores = await DB.get().collection('meter_restore').find(query).sort({mTime:-1}).toArray();
                if (restores && restores.length > 0) {
                    docs = docs.concat(restores);
                }
            }

            if (!docs || docs.length === 0) {
                // 보낼 데이터가 없으면 어떻게 하지??
                return -9;
            }

            let tx = new TxMeterOutageDump();
            tx.fromModels(docs as Array<MeterOutage>);

            let result = await conn.socket.sendDump('f', tx, docs, rx.header.qsn.v, 3, MeterOutageJob.onSend);
            return result === 0? 1 : -2;
        }

        return 0;
    }

    static async onSend(data: NData | NDumpSplit) {
        if (! (data instanceof NDumpSplit)) {
            Logger.warn(`MeterOutage_Job.onSend : data is not instanceof NDumpSplit`);
            return;
        }

        let sub = data.twoHead;
        if (! (sub instanceof TxMeterOutageSubDump)) {
            Logger.warn(`MeterOutage_Job.onSend : sub is not instanceof TxMeterOutageSubDump`);
            return;
        }

        let mid = sub.mid.v;
        let mOutageTimes = [];
        let mRestoreTimes = [];
        for(let item of data.array) {
            if (item instanceof TxMeterOutage) {
                if (item.dataType.v === 0x01) {
                    mOutageTimes.push(item.mTime.v);
                } else {
                    mRestoreTimes.push(item.mTime.v);
                }
            }
        }

        try {
            let query = {mid, mTime: {$in: mOutageTimes}, tx: 1};
            let result = await DB.get().collection('meter_outage').updateMany(query, {$unset: {tx: 1}});
            Logger.info(`>> meter_outage.onSend : matchedCount: [${result.matchedCount}], modifedCount: [${result.modifiedCount}]`);
        } catch(err) {
            Logger.warn(`!!_!! _db.meter_outage.updateMany_\n${err.message}`);
        }
        try {
            let query = {mid, mTime: {$in: mRestoreTimes}, tx: 1};
            let result = await DB.get().collection('meter_restore').updateMany(query, {$unset: {tx: 1}});
            Logger.info(`>> meter_restore.onSend : matchedCount: [${result.matchedCount}], modifedCount: [${result.modifiedCount}]`);
        } catch(err) {
            Logger.warn(`!!_!! _db.meter_restore.updateMany_\n${err.message}`);
        }
    }
}