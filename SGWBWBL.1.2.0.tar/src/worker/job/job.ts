import {FepPacket} from '../../fep/packet';
import {FepConn} from '../../fep';
import {env} from '../../env';
import {Utils, Logger} from '../../common';
import {DefaultConfigOptions} from '../../env/config_options';

export abstract class Job {
    jobName: string;
    periodName?: string;
    lastTicks: number;

    constructor(jobName: string, periodName?: string) {
        this.jobName = jobName;
        this.periodName = periodName;
        this.lastTicks = 0;
    }

    async onStart() {
    }

    async onUpdate() {
        if (!this.periodName) {
            return;
        }

        // 주기가 변경될 수 있으니 매번 읽어온다.
        let options: any = env.config.options;
        let defaultOptions: any = DefaultConfigOptions;
        let period: number = options[this.periodName];

        // 순시값의 경우 수집주기가 0이면 수집도 하지 않는다. (다른 값들은 0이면 디폴트 주기를 사용한다.)
        if (this.periodName === 'insPeriod' && period === 0) {
            return;
        }

        // 주기가 0이면 push하지 않는다.
        let push = (period !== 0);

        // 주기가 0이거나 undefined/null 이면 default 값을 읽는다.
        // 0이면 push하지 않지만, undefined/null 이면 push 하는 차이가 있음
        let realPeriod = period || defaultOptions[this.periodName];
        if (realPeriod > 0) {
            realPeriod *= 60 * 1000;
            let ticks = Date.now();
            if (ticks >= this.lastTicks + realPeriod) {
                this.lastTicks = ticks;

                Logger.info(`\n\n====================  job(${this.jobName}).collect start  ====================\n`);
                let data = await this.collect();
                Logger.info(`\n--------------------  job(${this.jobName}).collect end  --------------------\n\n`);
                if (data && push) {
                    await this.push(data);
                }
            }
        }
    }

    async collect(): Promise<any> {
        return null;
    }

    async push(data: any, args?: any) {
        if (!data) {
            return;
        }

        Logger.info(`\n\n====================  job(${this.jobName}).push start  ====================\n`);
        let result = await this.doPush(data, args);
        Logger.info(`\n--------------------  job(${this.jobName}).push end  --------------------\n\n`);
        if (result === 0) {
            return;
        }

        // 실패하면 다음에 2회 더 (총 3회) 시도한다.
        setImmediate(async ()=>{
            for(let i = 1; i < 3; ++i) {
                await Utils.sleep(env.config.options.trapInterval * 60 * 1000);

                Logger.info(`\n\n====================  job(${this.jobName}).push[${i}] start  ====================\n`);
                let result = await this.doPush(data, args);
                Logger.info(`\n--------------------  job(${this.jobName}).push[${i}] end  --------------------\n\n`);
                if (result === 0) {
                    return;
                }
            }
        });
    }

    async trap(data: any, args?: any) {
        if (!data) {
            return;
        }

        Logger.info(`\n\n====================  job(${this.jobName}).trap start  ====================\n`);
        let result = await this.doTrap(data, args);
        Logger.info(`\n\n--------------------  job(${this.jobName}).trap end  --------------------\n\n`);
        if (result === 0) {
            return;
        }

        // 실패하면 다음에 2회 더 (총 3회) 시도한다.
        setImmediate(async ()=>{
            for(let i = 1; i < 3; ++i) {
                await Utils.sleep(env.config.options.trapInterval * 60 * 1000);

                Logger.info(`\n\n==========  job(${this.jobName}).trap[${i}] start  ==========\n`);
                let result = await this.doTrap(data, args);
                Logger.info(`\n\n----------  job(${this.jobName}).trap[${i}] end  ----------\n\n`);

                if (result === 0) {
                    return;
                }
            }
        });
    }

    async doPush(data: any, args?: any): Promise<number> { return 0; }
    async doTrap(data: any, args?: any): Promise<number> { return 0; }

    // 해당사항 없으면 0, 처리대상인데 성공이면 양수, 처리대상인데 실패이면 음수
    async response(rx: FepPacket, conn: FepConn): Promise<number> { return 0; }
}