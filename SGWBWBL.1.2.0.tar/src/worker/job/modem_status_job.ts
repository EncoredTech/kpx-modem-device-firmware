import {FepConn} from '../../fep';
import {ModemStatus} from '../../data';
import {Job} from './job';
import {ModemAgent} from '../agent';
import {Utils} from '../../common'
import {env, ENV} from '../../env';
import {FepPacket, RxModemStatus, RxModemSetupInfo, RxModemSetupReset, TxModemStatus} from '../../fep/packet';

export class ModemStatusJob extends Job {
    modem: ModemAgent;
    status: ModemStatus | null;

    constructor(modem: ModemAgent) {
        super('ModemStatus', 'msPeriod');
        this.modem = modem;
        this.status = null;
    }

    async onStart() {
        // 부팅시 모뎀 상태를 Trap보고한다.
        let status = await this.collect();
        await this.trap(status);
    }

    async collect() {
        this.status = await this.modem.collectModemStatus();
        return this.status;
    }

    async doPush(data: ModemStatus): Promise<number> {
        let tx = new TxModemStatus();
        tx.fromModel(data);
        return await FepConn.startTrap('b', tx, data);
    }

    async doTrap(data: ModemStatus): Promise<number> {
        let tx = new TxModemStatus();
        tx.fromModel(data);
        return await FepConn.startTrap('b', tx, data);
    }

    async response(rx: FepPacket, conn: FepConn): Promise<number> {
        let data = rx.data;

        if (data instanceof RxModemStatus) {
            if (!this.status) {
                await this.collect();
            }
            if (!this.status) {
                return -9;
            }
            let tx = new TxModemStatus();
            tx.fromModel(this.status);

            let result = await conn.socket.sendData('b', tx, this.status, rx.header.qsn.v, 3, true);
            return result === 0? 1 : -2;
        }
        else if (data instanceof RxModemSetupInfo) {
            ENV.saveOptions(data);
            let status = await this.collect();
            await this.trap(status);

            return 2;
        }
        else if (data instanceof RxModemSetupReset) {
            await conn.socket.sendAck(rx.header.qsn.v);

            if (data.resetMode.v === 0x01) {
                Utils.reboot();
            }
            else if (data.resetMode.v === 0x02) {
                Utils.factoryReset();
            }

            return 2;
        }

        return 0;
    }
}