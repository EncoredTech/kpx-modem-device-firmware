import {exec, ExecException, ExecOptions} from 'child_process';
import {EOL} from 'os';
import {env} from '../env';
import {Mutex, Logger} from '../common';

export class GuruxLib {
    static cmdBase: any;
    static mutex: Mutex;
    
    static prepare() {
        let serverAddr = 144 + (Number(env.config.settings.meterId) % 100);
        GuruxLib.cmdBase = env.config.internal.cmd_base + ' -s ' + serverAddr + ' ';
        GuruxLib.mutex = new Mutex();
    }

    static async collectData(obisCodeAttrs: string | Array<string>) : Promise<Array<string> | null> {
        obisCodeAttrs = (typeof obisCodeAttrs === 'string')? [obisCodeAttrs] : obisCodeAttrs;
        let args = ' -g "';
        for(let obisCodeAttr of obisCodeAttrs) {
            args += `${obisCodeAttr};`;
        }
        args += '"';

        let count = obisCodeAttrs.length;
        return await GuruxLib.exec(args, {timeout: 5000 + 3000*count, maxBuffer: 10 * 1024 * count});
    }

    static async writeData(obisCodeAttr: string, classId: string, dataType: string, value: string) {
        let args = ` -w "${obisCodeAttr}:${classId}:${dataType}:${value}" `;
        await GuruxLib.exec(args);
    }

    static async collectLoadProfiles(startIndex: number): Promise<Array<Array<string>> | null> {
        let args = ` -z "LPE:${startIndex}:0" `;
        return await GuruxLib.exec(args, {timeout: (startIndex > 0 ? (5000 + 3000*100) : 10000), maxBuffer: 10*1024*(startIndex > 0 ? 100 : 1)});
    }

    static async collectLoadProfileByRange(start: Date, end: Date): Promise<Array<Array<string>> | null> {
        let startDate = `${start.getFullYear()}-${start.getMonth()+1}-${start.getDate()}-${start.getHours()}-${start.getMinutes()}-${start.getSeconds()}`;
        let endDate = `${end.getFullYear()}-${end.getMonth()+1}-${end.getDate()}-${end.getHours()}-${end.getMinutes()}-${end.getSeconds()}`;
        let argsLPI = ` -z "LPI:${startDate}:${endDate}" `;

        let res = await GuruxLib.exec(argsLPI, {timeout: 10000, maxBuffer: 10*1024});
        if (res?.length !== 3) {
            return null;
        }

        let startIndex = Number(res[0]);
        let endIndex = Number(res[1]);
        let buffSize = Number(res[2]);

        // 100개씩 나누어 읽어들인다.
        let remainCount = (endIndex >= startIndex) ? (endIndex - startIndex + 1) : (buffSize - startIndex + 1 + endIndex);
        let index = endIndex + 1;
        let array: Array<any> = [];
        while (remainCount > 0) {
            let tryCount = (remainCount >= 100) ? 100 : (remainCount);
            remainCount -= tryCount;

            index -= (tryCount);
            if (index <= 0) {
                index = buffSize - index;
            }

            let argsLPE = ` -z "LPE:${index}:${index + tryCount - 1}" `;
            let res2 = await GuruxLib.exec(argsLPE, {timeout: (5000 + 3000*tryCount), maxBuffer: 10*1024*tryCount});
            if (res2) {
                array = array.concat(res2);
            }
        }

        return array;
    }

    static async collectProfileGenericByEntity(obisCode: string, index: number, count: number): Promise<Array<Array<string>> | null> {
        let args = ` -z "PGE:${obisCode}:${index}:${count}" `;
        return await GuruxLib.exec(args, {timeout: 5000 + 3000*count, maxBuffer: 10*1024*count});
    }
/*
    static async collectProfileGenericByRange(obisCode: string, start: Date, end: Date): Promise<Array<Array<string>> | null> {
        let startDate = `${start.getFullYear()}-${start.getMonth()+1}-${start.getDate()}-${start.getHours()}-${start.getMinutes()}-${start.getSeconds()}`;
        let endDate = `${end.getFullYear()}-${end.getMonth()+1}-${end.getDate()}-${end.getHours()}-${end.getMinutes()}-${end.getSeconds()}`;
        let args = ` -z "PGR:${obisCode}:${startDate}:${endDate}" `;

        // 5분당 1개 정도가 저장되어 있음
        let diff5Min = Math.ceil(Math.abs((end.getTime() - start.getTime()) / (1000 * 60 * 5)));
        let timeout = 5000 + 3000*diff5Min;

        return await GuruxLib.exec(args, {timeout, maxBuffer: 10*1024*1024});
    }
*/
    static async exec(args: string, options?: ExecOptions): Promise<Array<any> | null> {
        options = Object.assign({
            shell: '/bin/bash',
            timeout: 5000,
            maxBuffer: 10*1024,
            killSignal: 'SIGKILL'
        }, options);

        let cmd = GuruxLib.cmdBase + ' ' + args;
        let resultText: string|null = null;

        try{
            await GuruxLib.mutex.lock();
            Logger.debug(`\n>> gurux_cmd : \n${cmd}\n`);
            resultText = await new Promise((resolve, reject)=> {
                exec(cmd, options, (error: ExecException|null, stdout: string|Buffer, stderr: string|Buffer)=>{
                    if (error) {
                        reject(error);
                    } else {
                        Logger.debug(`>> gurux_stdout : \n${stdout.toString()}\n`);
                        if (stderr) {
                            Logger.debug(`>> gurux_stderr : \n${stderr.toString}\n`);
                        }
                        resolve(stdout.toString());
                    }
                });
            })
        }
        catch(err) {
            Logger.warn(`GuruxLib.exec [${args}] : ${err.message}`);
            return null;
        }
        finally {
            GuruxLib.mutex.unlock();
        }

        try {
            if (resultText) {
                const errorTag = `$$$___GX_ERROR___$$$`;
                let errorIndex = resultText.indexOf(errorTag);
                if (errorIndex >= 0) {
                    return null;
                }

                const startTag = `$$$___GX_RESPONSE_START___$$$${EOL}`;
                const endTag = `$$$___GX_RESPONSE_END___$$$`;

                let startIndex = resultText.indexOf(startTag);
                let endIndex = resultText.indexOf(endTag);
                if (startIndex < 0 || endIndex < 0 || startIndex > endIndex) {
                    return null;
                }

                let dataText = resultText.substring(startIndex + startTag.length, endIndex);
                let data = JSON.parse(dataText);

                if (Array.isArray(data)) {
                    return data;
                }
            }
            else {
                Logger.warn(`GuruxLib.exec result [${args}] : null`);
            }
        } catch(err) {
            Logger.warn(`GuruxLib.exec result [${args}] : ${err.message}`);
        }

        return null;
    }
}