const ffi = require('ffi-napi')

//int KeyGen(BYTE* out, int outLen, const BYTE* otherInput, int otherInputLen, const BYTE* key, int keyLen);
//int Sign(BYTE* out, int outLen, const BYTE* msg, int msgLen, const BYTE* priKey, int priKeyLen);
//int Verify(const BYTE* msg, int msgLen, const BYTE* sig, int sigLen, const BYTE* pubKey, int pubKeyLen);
//int GenerateRand(BYTE* out, int outLen);
//int EncryptAuth (BYTE* out, int outLen, const BYTE* in, int inLen, BYTE* authData, int authDataLen, BYTE* iv, int ivLen, const BYTE* key, int keyLen, int tagLen);
//int DecryptAuth (BYTE* out, int outLen, const BYTE* in, int inLen, BYTE* authData, int authDataLen, BYTE* iv, int ivLen, const BYTE* key, int keyLen, int tagLen);

export class CisLib {
    static lib: any;

    static prepare(): number {
        this.lib = ffi.Library('./lib/libcis_encored', {
            'Initialize': ['int', []],
            'Finalize': ['int', []],
            'KeyGen': [ 'int', ['BYTE*', 'int', 'BYTE*', 'int', 'BYTE*', 'int'] ],
            'Sign': [ 'int', ['BYTE *', 'int', 'BYTE *', 'int', 'BYTE *', 'int'] ],
            'Verify': [ 'int', ['BYTE *', 'int', 'BYTE *', 'int', 'BYTE *', 'int'] ],
            'GenerateRand': [ 'int', ['BYTE *', 'int'] ],
            'EncryptAuth': [ 'int', ['BYTE *', 'int', 'BYTE *', 'int', 'BYTE *', 'int', 'BYTE *', 'int', 'BYTE *', 'int', 'int'] ],
            'DecryptAuth': [ 'int', ['BYTE *', 'int', 'BYTE *', 'int', 'BYTE *', 'int', 'BYTE *', 'int', 'BYTE *', 'int', 'int'] ]
          });
        return this.lib.Initialize();
    }

    static close(): number {
        return this.lib.Finalize();
    }

    static KeyGen(out: Buffer, otherInput: Buffer, key: Buffer): number {
        return this.lib.KeyGen(out, out.length, otherInput, otherInput.length, key, key.length);
    }

    static Sign(out: Buffer, msg: Buffer, priKey: Buffer): number {
        return this.lib.Sign(out, out.length, msg, msg.length, priKey, priKey.length);
    }

    static Verify(msg: Buffer, sig: Buffer, pubKey: Buffer): number {
        return this.lib.Verify(msg, msg.length, sig, sig.length, pubKey, pubKey.length);
    }

    static GenerateRand(out: Buffer): number {
        return this.lib.GenerateRand(out, out.length);
    }

    static EncryptAuth(out: Buffer, plainData: Buffer, aad: Buffer, iv: Buffer, key: Buffer, tagLen: number): number {
        return this.lib.EncryptAuth(out, out.length, plainData, plainData.length, aad, aad.length, iv, iv.length, key, key.length, tagLen);
    }

    static DecryptAuth(out: Buffer, encData: Buffer, aad: Buffer, iv: Buffer, key: Buffer, tagLen: number): number {
        return this.lib.DecryptAuth(out, out.length, encData, encData.length, aad, aad.length, iv, iv.length, key, key.length, tagLen);
    }
}